import numpy as np
import pandas as pd
import scipy.stats as stat
import matplotlib.pyplot as plt
from lammps import lammps
import os
import sys
import random

#basic setup

kb = 8.6173303e-5 #boltzmann (eV)

#to run lammps simulation

lmp = lammps()

#rows of log file to keep

keep = np.arange(86,188)

#setting initial velocity from temperature

def get_velocity(mu,T):
    m = 931494697.25613*mu #ev/c^2
    v = np.sqrt(3*kb*T/m)*2.998*10**6 #angstrom/picosecond
    return v

#writing input file

def write_input(filename):
    with open(filename,'w') as f:
        intro = 'units metal \ndimension 3 \natom_style atomic\nlog output.txt\npair_style morse 10\nboundary p p p \nregion simulation_box block -100 100 -100 100 -100 100 \ncreate_box 2 simulation_box \n'
        create = 'create_atoms 1 random 200 '+seed1+' simulation_box \ngroup ' + name1 + ' id 1:200 \ncreate_atoms 2 random 200 '+seed2+' simulation_box \ngroup '+name2+' id 201:400 \n'
        setup = 'mass 1 '+str(mu1)+'\nmass 2 '+' '+str(mu2)+'\nvelocity '+ name1 + ' create '+str(v1)+' '+seed1+' dist gaussian\nvelocity ' + name2 + ' create '+str(v2)+' '+seed2+' dist gaussian \n'
        pairs = 'pair_coeff 1 1 0 0 0\n' + 'pair_coeff 1 2 ' + str(D0) + ' '+str(a) + ' '+str(r)+'\n'+'pair_coeff 2 2 0 0 0\n'
        fixes = 'fix mynve all nve\nfix nvt all nvt temp ' +str(T)+' '+str(T) + ' $(100.0*dt)\n'
        equalize = 'thermo 1000\nrun 5000\nreset_timestep 0\n'
        vacf = 'compute vacf_Sn all vacf\nfix 5 all vector 1 c_vacf_Sn[4]\nvariable vacf_Sn equal 0.333*dt*trap(f_5)\n'
        thermo = 'thermo_style custom step temp v_vacf_Sn\n'
        run = 'thermo 50000\nrun 5000000\n'
        clear = 'clear'
        total  = [intro,create,setup,pairs,fixes,equalize,vacf,thermo,run,clear]
        f.writelines(total)
        f.close()
        
#calculating diffusion coefficient*press


def get_pD(logpath):
    df = pd.read_csv(logpath,skiprows=lambda x: x not in keep,sep = '\s+')
    df = df.drop(df.tail(1).index)
    D = df['v_vacf_Sn']*10**(-8) #l^2/t
    Davg = np.average(D[60:])
    Derr = np.std(D[60:])
    temp = df['Temp'].astype(float)
    pavg = np.average(temp[1:])*1.380649*10**(-23)*200/(200**3*10**(-30))
    pD = pavg*Davg
    err = pavg*Derr
    return pD,err

pD = []
Error = []

def pDlit(t):
    return 3.68*10**(-5)*t**1.712/np.exp(16.9/t)*101325/10**4

if __name__ == '__main__':
    params = pd.read_csv(sys.argv[1])
    
    name1 = params['Species 1'][0]
    name2 = params['Species 2'][0]
    mu1 = float(params['Molecular Mass 1'][0])
    mu2 = float(params['Molecular Mass 2'][0])
    D0 = float(params['D0'][0])
    a = float(params['a'][0])
    r = float(params['r'][0])
    Temps = np.linspace(float(params['t_low'][0]),float(params['t_high'][0]),num=int(params['num_sim'][0]))
    t = np.linspace(float(params['t_low'][0]),float(params['t_high'][0]))

    
    for i in Temps:
        seed1  = str(random.randint(100000,999999))
        seed2 = str(random.randint(100000,999999))
        T = i
        name = 'input.lmp'
        v1 = get_velocity(mu1,T)
        v2 = get_velocity(mu2,T)
        write_input(name)
        lmp.file(name)
        pressd,err = get_pD('output.txt')
        #pressd = get_pD('output.txt')
        pD.append(pressd)
        Error.append(err)
        print(Error)

    plt.figure(dpi=200)
    plt.plot(Temps,pD,'+-',label='Simulation')
    plt.errorbar(Temps,pD,yerr = Error,fmt = 'o',capsize=10)
    #plt.plot(t,pDlit(t),label = 'Literature')
    plt.xlabel('Temperature (K)')
    plt.ylabel('Diffusion Coefficient * Pressure ($\\frac{Pa{\\cdot}m^2}{s}$)')
    plt.title('P*D vs T')
    plt.legend()
    plt.show()
