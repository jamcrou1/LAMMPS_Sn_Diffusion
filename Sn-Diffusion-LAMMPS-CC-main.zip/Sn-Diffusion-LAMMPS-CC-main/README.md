Required Packages
-----------------------

numpy

pandas

scipy

matplotlib

lammps

os

sys

random

Installing Lammps
-----------------------

A LAMMPS executible for Windows can be installed on the following site: https://packages.lammps.org/windows.html

This will also install the Python library.

Input File
-----------------------

The input file is a CSV file, to be formatted identically to the given params.csv file. Molecular mass is in u. ```D0```, ```a``` and ```r``` represent the morse potential parameters for the Sn-H2 interaction. ```t_low``` and ```t_high``` represent the boundaries for the temperature range, in K.
Below is an example of how the input file should be formatted:

```
Species 1 Species 2 Molecular Mass 1  Molecular Mass 2 D0     a	    r     t_low   t_high   num_sim
Sn        H2        118.710           2.01568          0.0322 1.839 2.893 300     1000     10
```

Running the Simulation
-----------------------

In console:

```
$ python3 morsemsd.py morseparams.csv
```

Output
-----------------------

Outputs a graph of Pressure (Pa) times the Diffusion Coefficient ($m^{-2}s^{-1}$) vs the temperature in Kelvin, for each LAMMPS simulation. Plots a graph for Tin-Hydrogen interactions as found in literature. Below is an example of the output, using an input file with 10 temperature steps.

![Sample plot with 10 temperature steps](Figure_1.png)

Theory
-----------------------

testnew.py generates 200 $H_2$ molecules and 200 $Sn$ atoms randomly within a s = 200 Å cube with periodic boundaries. They are assigned velocities corresponding to the temperature of the system. A Lennard-Jones potential is used to simulate interactions - intraspecies interactions are neglected while interspecies interactions are considered. A Nose-Hoover thermostat is used to fix the temperature of the ensemble.

LAMMPS first undergoes an equilibration run with 5000 steps of 1 femtosecond. The data gathering run is 5 million steps of 1 femtosecond. LAMMPS outputs the velocity autocorrelation function, temperature, pressure and timestep, every 50,000 steps.


The first method to calculate the diffusion coefficient used is through the velocity autocorrelation function, as seen within ```morsevacf.py```. The diffusion coefficient is calculated through the following steps:

$v_i=v_x(t),v_y(t),v_z(t)$

$\langle v_i(0) \cdot v_i(t) \rangle = \frac{1}{N} \sum ^N _{i=1} v_i(t=t_0) \cdot v_i(t=t_0+\Delta t)$

Where N is the total amount of molecules.

$D = \frac{1}{3}\int^t_0\langle v_i(0) \cdot v_i(t) \rangle dt$


This integral is evaluated numerically using a trapezoidal Reimann sum. After a long time, found to be about 500 ps, it stops increasing and becomes constant. For each simulation, the diffusion coefficient is averaged between t = 3ns and t = 5ns. This value is then multiplied by the average pressure across this period of time.

This process is repeated for each temperature in the temperature range specified. Data obtained through this method is very noisy although a general trend is visibile in the data. This code can be modified to run with more atoms, which may solve this issue.

The mean square displacement is also used to find the diffusion coefficient in ```morsemsd.py```. The relation for finding $D$ is shown below.

$\langle r^2 \rangle = 6Dt+C$

The slope of the MSD graph plotted against time is used to find the diffusion coefficient; this value is found to converge about halfway through the simulation. Data is averaged between 4 and 5 million steps, and is found the be accurate to previous results. It is recommended to use ```morsemsd.py``` over ```morsevacf.py```.


Useful Links
-----------------------
https://docs.lammps.org/compute_msd.html

https://docs.lammps.org/compute_vacf.html

http://utkstair.org/clausius/docs/mse614/pdf/diffusion_intro_v02.pdf

https://c4science.ch/source/lammps/browse/master/examples/DIFFUSE/

